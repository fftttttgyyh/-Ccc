
import { useState } from 'react';
import fs from 'fs';
import path from 'path';

export default function Admin() {
  const [seasonTitle, setSeasonTitle] = useState('');
  const [episodeTitle, setEpisodeTitle] = useState('');
  const [videoUrl, setVideoUrl] = useState('');

  const handleAddSeason = () => {
    alert('Добавление сезона работает только при прямом доступе к серверу!');
  };

  const handleAddEpisode = () => {
    alert('Добавление серии работает только при прямом доступе к файлам!');
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Админка</h1>
      <h2>Добавить сезон</h2>
      <input value={seasonTitle} onChange={e => setSeasonTitle(e.target.value)} placeholder="Название сезона" />
      <button onClick={handleAddSeason}>Добавить сезон</button>
      <h2>Добавить серию</h2>
      <input value={episodeTitle} onChange={e => setEpisodeTitle(e.target.value)} placeholder="Название серии" />
      <input value={videoUrl} onChange={e => setVideoUrl(e.target.value)} placeholder="Ссылка на видео" />
      <button onClick={handleAddEpisode}>Добавить серию</button>
    </div>
  );
}
