
import { useRouter } from 'next/router';
import Link from 'next/link';
import data from '../../data/db.json';

export default function SeasonPage() {
  const router = useRouter();
  const { id } = router.query;
  const season = data.seasons.find(s => s.id === parseInt(id));

  if (!season) return <div>Сезон не найден</div>;

  return (
    <div style={{ padding: 20 }}>
      <h1>{season.title}</h1>
      <ul>
        {season.episodes.map(ep => (
          <li key={ep.id}>
            <Link href={`/season/${id}/episode/${ep.id}`}>{ep.title}</Link>
          </li>
        ))}
      </ul>
      <Link href="/">← Назад</Link>
    </div>
  );
}
