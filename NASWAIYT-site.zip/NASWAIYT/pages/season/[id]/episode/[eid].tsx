
import { useRouter } from 'next/router';
import data from '../../../../data/db.json';

export default function EpisodePage() {
  const router = useRouter();
  const { id, eid } = router.query;
  const season = data.seasons.find(s => s.id === parseInt(id));
  const episode = season?.episodes.find(e => e.id === parseInt(eid));

  if (!episode) return <div>Серия не найдена</div>;

  return (
    <div style={{ padding: 20 }}>
      <h1>{episode.title}</h1>
      <iframe width="560" height="315" src={episode.videoUrl} allowFullScreen></iframe>
    </div>
  );
}
