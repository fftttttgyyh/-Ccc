
import Link from 'next/link';
import data from '../data/db.json';

export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Сезоны</h1>
      <ul>
        {data.seasons.map(season => (
          <li key={season.id}>
            <Link href={`/season/${season.id}`}>Сезон {season.title}</Link>
          </li>
        ))}
      </ul>
      <Link href="/admin">Перейти в админку</Link>
    </div>
  );
}
